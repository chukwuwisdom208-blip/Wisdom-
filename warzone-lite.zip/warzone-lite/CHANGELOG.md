# Changelog

## 0.1.0 - Phase 1: Foundation (UNTESTED on device at time of writing)
Added: project setup + Android export preset (arm64, landscape), GitHub Actions APK build with size check,
startup animation, local login system, profile, animated 3D lobby, level + rank systems (data-driven),
settings (graphics preset/shadows/AA/FPS cap/FPS counter, look sensitivity, FOV, invert Y, touch opacity/size, dev tools),
training range with touch controls.
Known gaps: no audio, no resolution scaling, no weapons/AI/modes, recovery uses an on-device code.
