# WARZONE LITE: OPERATION LAST DOMINION

Lightweight Android FPS built with **Godot 4.3** (GL Compatibility renderer, arm64 only, no external art/audio assets so the APK stays small).

## Status: Phase 1 (Foundation) - see CHANGELOG.md

Implemented: startup animation, login (sign in / create account / guest / remember me / recovery code), profile, 3D animated lobby, level (1-100) and rank systems with animated progress bars, settings, training range with touch movement / look / jump / sprint / crouch.

NOT implemented yet: weapons, AI, game modes, maps, BR mechanics, vehicles, operators' abilities, audio, HUD editor, online play, content manager. Nothing in the UI pretends otherwise.

## Getting the APK (cloud build, no PC needed)
1. Create a GitHub repo, upload `warzone-lite.zip` to the repo root.
2. Create the file `.github/workflows/build.yml` (content in this repo) and commit.
3. Open the **Actions** tab, wait for "Build Android APK" to finish (about 5-10 min).
4. Open **Releases**, download `WarzoneLite.apk`, install it (allow "install unknown apps").
The workflow fails on purpose if the APK is over 100 MB and prints the real size.

## Layout
- `data/` - ranks.json (rank table), progression.json (XP curve): edit to rebalance, no code change.
- `scripts/core/` - autoloads: GameData, SaveSystem, Auth, GameSettings.
- `scripts/systems/` - RankSystem, LevelSystem (pure logic).
- `scripts/ui/` - UIKit (theme/widgets), SettingsPanel, AvatarBadge.
- `scripts/screens/` - boot, login, lobby, range.
- `scripts/gameplay/` - player, touch_controls.
- `scripts/entities/`, `scripts/lobby/` - operator model, lobby stage.

## Notes
- Accounts and saves are local to the device (user:// storage). Online auth/validation needs a backend (future).
- The APK is debug-signed (fine for side-loading). Release signing comes in Phase 8.
- Backup: keep each phase as a git tag (e.g. `phase-1`) or a copy of the zip.
