extends RefCounted
## Shared UI helpers and the military-themed look. All UI is built in code.

const BG := Color(0.043, 0.059, 0.078)
const PANEL := Color(0.078, 0.106, 0.137, 0.90)
const PANEL_SOLID := Color(0.078, 0.106, 0.137)
const BORDER := Color(0.20, 0.26, 0.33)
const ACCENT := Color(0.95, 0.66, 0.0)
const TEXT := Color(0.91, 0.93, 0.95)
const MUTED := Color(0.54, 0.59, 0.65)
const GOOD := Color(0.24, 0.86, 0.59)
const BAD := Color(1.0, 0.30, 0.43)


static func sb(bg: Color, border: Color = Color(0, 0, 0, 0), radius: int = 10, border_w: int = 0, pad: int = 12) -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = bg
	s.border_color = border
	s.set_border_width_all(border_w)
	s.set_corner_radius_all(radius)
	s.content_margin_left = pad
	s.content_margin_right = pad
	s.content_margin_top = pad
	s.content_margin_bottom = pad
	return s


static func circle_tex(d: int, c: Color) -> ImageTexture:
	var img := Image.create(d, d, false, Image.FORMAT_RGBA8)
	img.fill(Color(0, 0, 0, 0))
	var r := d / 2.0
	for y in d:
		for x in d:
			if Vector2(x + 0.5, y + 0.5).distance_to(Vector2(r, r)) <= r - 1.0:
				img.set_pixel(x, y, c)
	return ImageTexture.create_from_image(img)


static func make_theme() -> Theme:
	var t := Theme.new()
	t.default_font_size = 22
	t.set_stylebox("normal", "Button", sb(PANEL_SOLID, BORDER, 10, 2))
	t.set_stylebox("hover", "Button", sb(Color(0.11, 0.15, 0.19), BORDER, 10, 2))
	t.set_stylebox("pressed", "Button", sb(Color(0.16, 0.21, 0.27), ACCENT, 10, 2))
	t.set_stylebox("disabled", "Button", sb(Color(0.06, 0.08, 0.10), Color(0.12, 0.15, 0.18), 10, 2))
	t.set_stylebox("focus", "Button", StyleBoxEmpty.new())
	for c in ["font_color", "font_hover_color", "font_pressed_color", "font_focus_color"]:
		t.set_color(c, "Button", TEXT)
	t.set_color("font_disabled_color", "Button", Color(0.35, 0.39, 0.44))
	t.set_stylebox("normal", "LineEdit", sb(Color(0.05, 0.07, 0.09), BORDER, 8, 2))
	t.set_stylebox("focus", "LineEdit", sb(Color(0.05, 0.07, 0.09), ACCENT, 8, 2))
	t.set_color("font_color", "LineEdit", TEXT)
	t.set_color("font_placeholder_color", "LineEdit", MUTED)
	t.set_color("font_color", "Label", TEXT)
	t.set_stylebox("panel", "PanelContainer", sb(PANEL, BORDER, 14, 2, 18))
	t.set_stylebox("background", "ProgressBar", sb(Color(0.12, 0.15, 0.19), Color(0, 0, 0, 0), 8, 0, 0))
	t.set_stylebox("fill", "ProgressBar", sb(ACCENT, Color(0, 0, 0, 0), 8, 0, 0))
	t.set_stylebox("slider", "HSlider", sb(Color(0.16, 0.2, 0.25), Color(0, 0, 0, 0), 4, 0, 3))
	t.set_stylebox("grabber_area", "HSlider", sb(ACCENT, Color(0, 0, 0, 0), 4, 0, 3))
	t.set_stylebox("grabber_area_highlight", "HSlider", sb(ACCENT, Color(0, 0, 0, 0), 4, 0, 3))
	var grab := circle_tex(40, ACCENT)
	t.set_icon("grabber", "HSlider", grab)
	t.set_icon("grabber_highlight", "HSlider", grab)
	t.set_icon("grabber_disabled", "HSlider", grab)
	return t


static func label(text: String, size: int = 22, color: Color = TEXT) -> Label:
	var l := Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", color)
	return l


static func section(text: String) -> Label:
	return label(text, 20, ACCENT)


static func button(text: String, accent: bool = false) -> Button:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = Vector2(0, 62)
	b.focus_mode = Control.FOCUS_NONE
	if accent:
		b.add_theme_stylebox_override("normal", sb(ACCENT, ACCENT, 10, 0))
		b.add_theme_stylebox_override("hover", sb(ACCENT.lightened(0.15), ACCENT, 10, 0))
		b.add_theme_stylebox_override("pressed", sb(ACCENT.darkened(0.2), ACCENT, 10, 0))
		for c in ["font_color", "font_hover_color", "font_pressed_color", "font_focus_color"]:
			b.add_theme_color_override(c, BG)
	return b


static func segmented(options: Array, current: int, on_select: Callable) -> HBoxContainer:
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 8)
	var group := ButtonGroup.new()
	for i in options.size():
		var b := Button.new()
		b.text = str(options[i])
		b.toggle_mode = true
		b.button_group = group
		b.custom_minimum_size = Vector2(96, 52)
		b.focus_mode = Control.FOCUS_NONE
		b.add_theme_stylebox_override("pressed", sb(ACCENT, ACCENT, 8, 0))
		b.add_theme_stylebox_override("hover_pressed", sb(ACCENT, ACCENT, 8, 0))
		b.add_theme_color_override("font_pressed_color", BG)
		b.add_theme_color_override("font_hover_pressed_color", BG)
		row.add_child(b)
		b.button_pressed = (i == current)
		b.pressed.connect(on_select.bind(i))
	return row


static func row(text: String, control: Control) -> HBoxContainer:
	var r := HBoxContainer.new()
	r.add_theme_constant_override("separation", 16)
	var l := label(text, 22)
	l.custom_minimum_size = Vector2(300, 0)
	l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	r.add_child(l)
	r.add_child(control)
	return r


static func toggle_row(text: String, value: bool, on_toggle: Callable) -> CheckButton:
	var b := CheckButton.new()
	b.text = text
	b.button_pressed = value
	b.custom_minimum_size = Vector2(0, 56)
	b.focus_mode = Control.FOCUS_NONE
	b.toggled.connect(on_toggle)
	return b


static func slider_row(text: String, minv: float, maxv: float, step: float, value: float, fmt: String, on_change: Callable) -> HBoxContainer:
	var r := HBoxContainer.new()
	r.add_theme_constant_override("separation", 16)
	var l := label(text, 22)
	l.custom_minimum_size = Vector2(300, 0)
	l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	var s := HSlider.new()
	s.min_value = minv
	s.max_value = maxv
	s.step = step
	s.value = value
	s.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	s.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	s.custom_minimum_size = Vector2(240, 48)
	var v := label(fmt % value, 22, MUTED)
	v.custom_minimum_size = Vector2(80, 0)
	s.value_changed.connect(func(x: float) -> void:
		v.text = fmt % x
		on_change.call(x)
	)
	r.add_child(l)
	r.add_child(s)
	r.add_child(v)
	return r


static func toast(host: Control, text: String, color: Color = ACCENT) -> void:
	var l := label(text, 40, color)
	l.add_theme_color_override("font_outline_color", Color(0, 0, 0))
	l.add_theme_constant_override("outline_size", 8)
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	l.custom_minimum_size = Vector2(700, 0)
	l.position = Vector2((host.size.x - 700) / 2.0, 110)
	l.modulate.a = 0.0
	host.add_child(l)
	var tw := l.create_tween()
	tw.tween_property(l, "modulate:a", 1.0, 0.25)
	tw.tween_interval(1.8)
	tw.tween_property(l, "modulate:a", 0.0, 0.5)
	tw.tween_callback(l.queue_free)


## Opens a centred modal panel over `host`. Returns the modal root (queue_free it to close).
static func show_modal(host: Control, title: String, content: Control, close_text: String = "CLOSE", on_close: Callable = Callable()) -> Control:
	var root := Control.new()
	root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	root.process_mode = Node.PROCESS_MODE_ALWAYS
	var dim := ColorRect.new()
	dim.color = Color(0, 0, 0, 0.72)
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	root.add_child(dim)
	var center := CenterContainer.new()
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	root.add_child(center)
	var panel := PanelContainer.new()
	panel.custom_minimum_size = Vector2(minf(host.size.x - 80.0, 1000.0), minf(host.size.y - 60.0, 620.0))
	center.add_child(panel)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 14)
	panel.add_child(v)
	v.add_child(label(title, 34, ACCENT))
	var scroll := ScrollContainer.new()
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	content.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.add_child(content)
	v.add_child(scroll)
	var close := button(close_text, true)
	close.pressed.connect(func() -> void:
		root.queue_free()
		if on_close.is_valid():
			on_close.call()
	)
	v.add_child(close)
	host.add_child(root)
	return root
