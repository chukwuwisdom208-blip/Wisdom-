extends VBoxContainer
## Settings content (used in lobby and in the in-game pause menu).
## Only settings that actually change behaviour are listed.

const UIKit = preload("res://scripts/ui/ui_kit.gd")


func _ready() -> void:
	add_theme_constant_override("separation", 14)
	_rebuild()


func _clear() -> void:
	for c in get_children():
		remove_child(c)
		c.queue_free()


func _rebuild() -> void:
	_clear()
	var v: Dictionary = GameSettings.values

	add_child(UIKit.section("GRAPHICS"))
	var presets := ["low", "medium", "high"]
	var pi := presets.find(str(v["graphics_preset"]))
	add_child(UIKit.row("Preset" + ("  (custom)" if pi == -1 else ""),
			UIKit.segmented(["Low", "Medium", "High"], pi, _on_preset)))
	add_child(UIKit.toggle_row("Shadows", bool(v["shadows"]), func(on: bool) -> void:
		GameSettings.set_value("shadows", on)
		_rebuild.call_deferred()))
	add_child(UIKit.row("Anti-aliasing",
			UIKit.segmented(["Off", "2x", "4x"], [0, 2, 4].find(int(v["msaa"])), func(i: int) -> void:
				GameSettings.set_value("msaa", [0, 2, 4][i])
				_rebuild.call_deferred())))
	add_child(UIKit.row("Frame-rate cap",
			UIKit.segmented(["30", "60", "90", "120"], [30, 60, 90, 120].find(int(v["max_fps"])), func(i: int) -> void:
				GameSettings.set_value("max_fps", [30, 60, 90, 120][i])
				_rebuild.call_deferred())))
	add_child(UIKit.toggle_row("Show FPS counter", bool(v["show_fps"]), func(on: bool) -> void:
		GameSettings.set_value("show_fps", on)))
	add_child(UIKit.label("Recommended for this device: " + GameSettings.recommend_preset().capitalize(), 18, UIKit.MUTED))

	add_child(UIKit.section("CONTROLS"))
	add_child(UIKit.slider_row("Look sensitivity", 0.3, 3.0, 0.05, float(v["look_sensitivity"]), "%.2f",
			func(x: float) -> void: GameSettings.set_value("look_sensitivity", x)))
	add_child(UIKit.slider_row("Field of view", 60, 100, 1, float(v["fov"]), "%d",
			func(x: float) -> void: GameSettings.set_value("fov", int(x))))
	add_child(UIKit.toggle_row("Invert Y axis", bool(v["invert_y"]), func(on: bool) -> void:
		GameSettings.set_value("invert_y", on)))
	add_child(UIKit.slider_row("Button opacity", 0.2, 1.0, 0.05, float(v["touch_opacity"]), "%.2f",
			func(x: float) -> void: GameSettings.set_value("touch_opacity", x)))
	add_child(UIKit.slider_row("Button size", 0.7, 1.4, 0.05, float(v["touch_scale"]), "%.2f",
			func(x: float) -> void: GameSettings.set_value("touch_scale", x)))

	add_child(UIKit.section("DEVELOPER"))
	add_child(UIKit.toggle_row("Dev tools in lobby (test XP / rank / gold)", bool(v["dev_tools"]), func(on: bool) -> void:
		GameSettings.set_value("dev_tools", on)))

	var reset := UIKit.button("RESET ALL SETTINGS")
	reset.pressed.connect(func() -> void:
		GameSettings.reset_to_defaults()
		_rebuild.call_deferred())
	add_child(reset)


func _on_preset(i: int) -> void:
	GameSettings.apply_preset(["low", "medium", "high"][i])
	_rebuild.call_deferred()
