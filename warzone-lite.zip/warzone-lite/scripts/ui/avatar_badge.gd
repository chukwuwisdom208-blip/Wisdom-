extends Control
## Simple circular avatar: coloured disc with the player's initial.

const COLORS: Array[Color] = [
	Color(0.88, 0.65, 0.15), Color(0.35, 0.66, 1.0), Color(1.0, 0.48, 0.24),
	Color(0.24, 0.86, 0.59), Color(0.69, 0.42, 1.0), Color(1.0, 0.30, 0.43)]

var color_index: int = 0
var letter: String = "?"


func setup(idx: int, text: String, px: int) -> void:
	color_index = idx
	letter = text.left(1).to_upper()
	custom_minimum_size = Vector2(px, px)
	queue_redraw()


func _draw() -> void:
	var r := minf(size.x, size.y) / 2.0
	var c := size / 2.0
	draw_circle(c, r, Color(0.043, 0.059, 0.078))
	draw_circle(c, r - 4.0, COLORS[color_index % COLORS.size()])
	var font := ThemeDB.fallback_font
	var fs := int(r * 1.1)
	var ts := font.get_string_size(letter, HORIZONTAL_ALIGNMENT_CENTER, -1, fs)
	draw_string(font, Vector2(c.x - ts.x / 2.0, c.y + fs * 0.35), letter,
			HORIZONTAL_ALIGNMENT_CENTER, -1, fs, Color(0.043, 0.059, 0.078))
