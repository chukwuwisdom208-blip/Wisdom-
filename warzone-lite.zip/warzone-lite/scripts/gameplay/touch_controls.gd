extends Control
## Multi-touch controls drawn and handled in one place (reliable multi-finger input):
##  - left half: floating move joystick
##  - rest of screen: drag to look
##  - buttons: JUMP, CROUCH (toggle), SPRINT (toggle), pause menu
## Size and opacity come from Settings.

signal menu_pressed

var move_vector := Vector2.ZERO
var sprint_on := false

var _look_accum := Vector2.ZERO
var _jump_flag := false
var _crouch_flag := false
var _joy_idx := -1
var _joy_origin := Vector2.ZERO
var _joy_pos := Vector2.ZERO
var _look_idx := -1
var _btn_touch := {}   # finger index -> button id


func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)


func reset() -> void:
	move_vector = Vector2.ZERO
	sprint_on = false
	_joy_idx = -1
	_look_idx = -1
	_btn_touch.clear()
	_look_accum = Vector2.ZERO


func consume_look() -> Vector2:
	var l := _look_accum
	_look_accum = Vector2.ZERO
	return l


func consume_jump() -> bool:
	var j := _jump_flag
	_jump_flag = false
	return j


func consume_crouch() -> bool:
	var c := _crouch_flag
	_crouch_flag = false
	return c


func _scale() -> float:
	return float(GameSettings.values["touch_scale"])


func _layout() -> Dictionary:
	var s := _scale()
	var w := size.x
	var h := size.y
	return {
		"jump": {"pos": Vector2(w - 140.0 * s, h - 150.0 * s), "r": 62.0 * s, "label": "JUMP"},
		"crouch": {"pos": Vector2(w - 300.0 * s, h - 90.0 * s), "r": 48.0 * s, "label": "CROUCH"},
		"sprint": {"pos": Vector2(w - 290.0 * s, h - 215.0 * s), "r": 48.0 * s, "label": "SPRINT"},
		"menu": {"pos": Vector2(w - 60.0, 60.0), "r": 34.0, "label": "II"},
	}


func _joy_radius() -> float:
	return 110.0 * _scale()


func _input(event: InputEvent) -> void:
	if not is_visible_in_tree():
		return
	if event is InputEventScreenTouch:
		if event.pressed:
			_press(event.index, event.position)
		else:
			_release(event.index)
	elif event is InputEventScreenDrag:
		_drag(event.index, event.position, event.relative)


func _press(index: int, pos: Vector2) -> void:
	var lay := _layout()
	for id in lay.keys():
		var b: Dictionary = lay[id]
		if pos.distance_to(b["pos"]) <= float(b["r"]) * 1.15:
			_btn_touch[index] = id
			if id == "jump":
				_jump_flag = true
			elif id == "crouch":
				_crouch_flag = true
			elif id == "sprint":
				sprint_on = not sprint_on
			elif id == "menu":
				menu_pressed.emit()
			return
	if pos.x < size.x * 0.45 and _joy_idx == -1:
		_joy_idx = index
		_joy_origin = pos
		_joy_pos = pos
	elif _look_idx == -1:
		_look_idx = index


func _release(index: int) -> void:
	if index == _joy_idx:
		_joy_idx = -1
		move_vector = Vector2.ZERO
	elif index == _look_idx:
		_look_idx = -1
	_btn_touch.erase(index)


func _drag(index: int, pos: Vector2, rel: Vector2) -> void:
	if index == _joy_idx:
		_joy_pos = pos
		var r := _joy_radius()
		var off := pos - _joy_origin
		if off.length() > r:
			_joy_origin += off.normalized() * (off.length() - r)
			off = pos - _joy_origin
		var v := off / r
		move_vector = Vector2.ZERO if v.length() < 0.12 else v.limit_length(1.0)
	elif index == _look_idx:
		_look_accum += rel


func _process(_delta: float) -> void:
	if move_vector.length() < 0.1:
		sprint_on = false
	queue_redraw()


func _draw() -> void:
	var op := float(GameSettings.values["touch_opacity"])
	var s := _scale()
	var font := ThemeDB.fallback_font
	var base := Color(1, 1, 1, op * 0.35)
	var line := Color(1, 1, 1, op)
	var accent := Color(0.95, 0.66, 0.0, op)
	if _joy_idx != -1:
		var r := _joy_radius()
		draw_circle(_joy_origin, r, base)
		draw_arc(_joy_origin, r, 0, TAU, 48, line, 3.0, true)
		var k := _joy_pos - _joy_origin
		draw_circle(_joy_origin + k.limit_length(r), 44.0 * s, line)
	else:
		var hint := Vector2(190.0 * s, size.y - 170.0 * s)
		draw_arc(hint, _joy_radius(), 0, TAU, 48, Color(1, 1, 1, op * 0.4), 3.0, true)
		draw_circle(hint, 44.0 * s, Color(1, 1, 1, op * 0.25))
	var lay := _layout()
	var pressed := _btn_touch.values()
	for id in lay.keys():
		var b: Dictionary = lay[id]
		var p: Vector2 = b["pos"]
		var r2: float = b["r"]
		var on := pressed.has(id) or (id == "sprint" and sprint_on) or (id == "crouch" and _crouch_active)
		draw_circle(p, r2, Color(0.95, 0.66, 0.0, op * 0.45) if on else base)
		draw_arc(p, r2, 0, TAU, 40, accent if on else line, 3.0, true)
		var fs := 18 if id != "menu" else 26
		var txt: String = b["label"]
		var ts := font.get_string_size(txt, HORIZONTAL_ALIGNMENT_CENTER, -1, fs)
		draw_string(font, p + Vector2(-ts.x / 2.0, fs * 0.35), txt, HORIZONTAL_ALIGNMENT_CENTER, -1, fs, line)


var _crouch_active := false


func set_crouch_state(on: bool) -> void:
	_crouch_active = on
