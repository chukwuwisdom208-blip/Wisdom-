extends CharacterBody3D
## First-person player: move, look, jump, sprint, crouch. Phase 1 only (no weapons yet).

const WALK_SPEED := 4.6
const SPRINT_SPEED := 7.6
const CROUCH_SPEED := 2.4
const JUMP_VELOCITY := 6.5
const GRAVITY := 20.0
const STAND_H := 1.8
const CROUCH_H := 1.1
const LOOK_RAD_PER_PX := 0.0035

var controls: Control = null
var head: Node3D
var camera: Camera3D
var capsule: CapsuleShape3D
var shape: CollisionShape3D
var pitch := 0.0
var crouching := false
var sprinting := false
var _spawn := Vector3.ZERO
var _prev_c := false
var _prev_space := false


func _ready() -> void:
	_spawn = position
	capsule = CapsuleShape3D.new()
	capsule.radius = 0.35
	capsule.height = STAND_H
	shape = CollisionShape3D.new()
	shape.shape = capsule
	shape.position.y = STAND_H / 2.0
	add_child(shape)
	head = Node3D.new()
	head.position.y = 1.6
	add_child(head)
	camera = Camera3D.new()
	camera.near = 0.05
	camera.far = 300.0
	head.add_child(camera)
	camera.current = true
	floor_snap_length = 0.3
	floor_max_angle = deg_to_rad(46.0)
	GameSettings.changed.connect(_apply_settings)
	_apply_settings()


func _apply_settings() -> void:
	camera.fov = float(GameSettings.values["fov"])


func state_text() -> String:
	if crouching:
		return "CROUCHING"
	if sprinting:
		return "SPRINTING"
	return ""


func _can_stand() -> bool:
	return not test_move(global_transform, Vector3(0, STAND_H - CROUCH_H + 0.05, 0))


func _set_crouch(on: bool) -> void:
	if not on and not _can_stand():
		return
	crouching = on
	capsule.height = CROUCH_H if on else STAND_H
	shape.position.y = capsule.height / 2.0
	if controls != null:
		controls.set_crouch_state(on)


func _physics_process(delta: float) -> void:
	var move := Vector2.ZERO
	var look := Vector2.ZERO
	var jump := false
	var want_sprint := false
	if controls != null:
		move = controls.move_vector
		look = controls.consume_look()
		jump = controls.consume_jump()
		want_sprint = controls.sprint_on
		if controls.consume_crouch():
			_set_crouch(not crouching)
	# Keyboard fallback (handy when testing on a PC)
	var kb := Vector2(
		float(Input.is_physical_key_pressed(KEY_D)) - float(Input.is_physical_key_pressed(KEY_A)),
		float(Input.is_physical_key_pressed(KEY_S)) - float(Input.is_physical_key_pressed(KEY_W)))
	move = (move + kb).limit_length(1.0)
	look += Vector2(
		float(Input.is_physical_key_pressed(KEY_RIGHT)) - float(Input.is_physical_key_pressed(KEY_LEFT)),
		float(Input.is_physical_key_pressed(KEY_DOWN)) - float(Input.is_physical_key_pressed(KEY_UP))) * 400.0 * delta
	want_sprint = want_sprint or Input.is_physical_key_pressed(KEY_SHIFT)
	var space := Input.is_physical_key_pressed(KEY_SPACE)
	if space and not _prev_space:
		jump = true
	_prev_space = space
	var c := Input.is_physical_key_pressed(KEY_C)
	if c and not _prev_c:
		_set_crouch(not crouching)
	_prev_c = c

	# Look
	var sens := float(GameSettings.values["look_sensitivity"]) * LOOK_RAD_PER_PX
	rotate_y(-look.x * sens)
	var ydir := -1.0 if bool(GameSettings.values["invert_y"]) else 1.0
	pitch = clampf(pitch - look.y * sens * ydir, -1.45, 1.45)
	head.rotation.x = pitch

	# Move
	sprinting = false
	var speed := WALK_SPEED
	if crouching:
		speed = CROUCH_SPEED
	elif want_sprint and move.y < -0.3:
		speed = SPRINT_SPEED
		sprinting = true
	var dir := transform.basis * Vector3(move.x, 0.0, move.y)
	var target := dir * speed
	var acc := 40.0 if is_on_floor() else 8.0
	velocity.x = move_toward(velocity.x, target.x, acc * delta)
	velocity.z = move_toward(velocity.z, target.z, acc * delta)
	if not is_on_floor():
		velocity.y -= GRAVITY * delta
	elif jump:
		if crouching:
			_set_crouch(false)
		if not crouching:
			velocity.y = JUMP_VELOCITY
	move_and_slide()

	var eye := 0.95 if crouching else 1.6
	head.position.y = lerpf(head.position.y, eye, minf(1.0, 12.0 * delta))
	if global_position.y < -20.0:
		global_position = _spawn
		velocity = Vector3.ZERO
