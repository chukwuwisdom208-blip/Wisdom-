extends Node3D
## Animated 3D lobby background: platform, pulsing light bars, floating dust, operator idle.

const OperatorModel = preload("res://scripts/entities/operator_model.gd")

var operator: Node3D
var cam: Camera3D
var _t := 0.0
var _bar_mats: Array[StandardMaterial3D] = []
var _ring_mat: StandardMaterial3D
var _accent := Color(0.95, 0.66, 0.0)


func _ready() -> void:
	_build_environment()
	_build_platform()
	_build_backdrop()
	_build_dust()
	operator = OperatorModel.new()
	add_child(operator)
	cam = Camera3D.new()
	cam.fov = 40.0
	add_child(cam)
	cam.look_at_from_position(Vector3(0, 1.25, 4.2), Vector3(0, 1.0, 0))
	cam.current = true


func _process(delta: float) -> void:
	_t += delta
	operator.idle(_t)
	cam.position.x = sin(_t * 0.3) * 0.15
	cam.look_at(Vector3(0, 1.0, 0))
	for k in _bar_mats.size():
		_bar_mats[k].emission_energy_multiplier = 1.3 + sin(_t * 1.2 + k * 0.7) * 0.9
	_ring_mat.emission_energy_multiplier = 2.0 + sin(_t * 2.0) * 0.8


func set_operator_colors(suit_idx: int, accent_idx: int) -> void:
	operator.set_colors(suit_idx, accent_idx)
	_accent = OperatorModel.ACCENT_COLORS[accent_idx % OperatorModel.ACCENT_COLORS.size()]
	_ring_mat.emission = _accent
	for m in _bar_mats:
		m.emission = _accent


func _build_environment() -> void:
	var env := Environment.new()
	env.background_mode = Environment.BG_COLOR
	env.background_color = Color(0.03, 0.05, 0.08)
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(0.28, 0.33, 0.42)
	env.ambient_light_energy = 0.8
	env.fog_enabled = true
	env.fog_light_color = Color(0.05, 0.08, 0.12)
	env.fog_density = 0.04
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	var we := WorldEnvironment.new()
	we.environment = env
	add_child(we)
	var key := DirectionalLight3D.new()
	key.rotation_degrees = Vector3(-35, 25, 0)
	key.light_energy = 1.2
	key.light_color = Color(1.0, 0.93, 0.85)
	key.add_to_group("sun")
	add_child(key)
	var rim := OmniLight3D.new()
	rim.position = Vector3(-2.5, 2.0, -2.0)
	rim.omni_range = 9.0
	rim.light_energy = 2.5
	rim.light_color = Color(0.3, 0.6, 1.0)
	add_child(rim)


func _build_platform() -> void:
	var mi := MeshInstance3D.new()
	var cm := CylinderMesh.new()
	cm.top_radius = 1.6
	cm.bottom_radius = 1.7
	cm.height = 0.2
	mi.mesh = cm
	var m := StandardMaterial3D.new()
	m.albedo_color = Color(0.1, 0.12, 0.14)
	m.metallic = 0.6
	m.roughness = 0.4
	mi.material_override = m
	mi.position.y = -0.1
	add_child(mi)
	var ring := MeshInstance3D.new()
	var tm := TorusMesh.new()
	tm.inner_radius = 1.55
	tm.outer_radius = 1.66
	ring.mesh = tm
	_ring_mat = StandardMaterial3D.new()
	_ring_mat.albedo_color = Color(0.05, 0.05, 0.05)
	_ring_mat.emission_enabled = true
	_ring_mat.emission = _accent
	ring.material_override = _ring_mat
	ring.position.y = 0.01
	ring.scale = Vector3(1, 0.3, 1)
	add_child(ring)
	var floor_mi := MeshInstance3D.new()
	var fm := CylinderMesh.new()
	fm.top_radius = 12.0
	fm.bottom_radius = 12.0
	fm.height = 0.02
	floor_mi.mesh = fm
	var fmat := StandardMaterial3D.new()
	fmat.albedo_color = Color(0.05, 0.06, 0.08)
	fmat.roughness = 0.6
	floor_mi.material_override = fmat
	floor_mi.position.y = -0.11
	add_child(floor_mi)


func _build_backdrop() -> void:
	for i in 11:
		var a := deg_to_rad(lerpf(-75.0, 75.0, i / 10.0))
		var h := 3.0 + (i % 3) * 1.2
		var mi := MeshInstance3D.new()
		var bm := BoxMesh.new()
		bm.size = Vector3(0.25, h, 0.25)
		mi.mesh = bm
		var mat := StandardMaterial3D.new()
		mat.albedo_color = Color(0.05, 0.06, 0.08)
		mat.emission_enabled = true
		mat.emission = _accent
		mi.material_override = mat
		mi.position = Vector3(sin(a) * 6.0, h / 2.0, -cos(a) * 6.0 - 1.0)
		add_child(mi)
		_bar_mats.append(mat)


func _build_dust() -> void:
	var p := CPUParticles3D.new()
	p.amount = 80
	p.lifetime = 8.0
	p.preprocess = 8.0
	p.emission_shape = CPUParticles3D.EMISSION_SHAPE_BOX
	p.emission_box_extents = Vector3(5, 2, 3)
	p.gravity = Vector3(0, 0.05, 0)
	p.direction = Vector3(0, 1, 0)
	p.spread = 180.0
	p.initial_velocity_min = 0.05
	p.initial_velocity_max = 0.2
	var sm := SphereMesh.new()
	sm.radius = 0.015
	sm.height = 0.03
	sm.radial_segments = 4
	sm.rings = 2
	var mat := StandardMaterial3D.new()
	mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mat.albedo_color = Color(0.7, 0.85, 1.0, 0.5)
	mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	sm.material = mat
	p.mesh = sm
	p.position = Vector3(0, 1.5, -1)
	add_child(p)
