extends Node3D
## Training range: a small test level for movement, look, jump, sprint, crouch.
## Everything is generated from primitives (no model/texture files).

const UIKit = preload("res://scripts/ui/ui_kit.gd")
const SettingsPanel = preload("res://scripts/ui/settings_panel.gd")
const PlayerScript = preload("res://scripts/gameplay/player.gd")
const TouchControls = preload("res://scripts/gameplay/touch_controls.gd")

var player: CharacterBody3D
var controls: Control
var ui: Control
var stance_label: Label
var _mats := {}
var _grid_tex: ImageTexture
var _paused := false


func _ready() -> void:
	_grid_tex = _make_grid_texture()
	_build_environment()
	_build_world()
	player = PlayerScript.new()
	player.position = Vector3(0, 0.1, 0)
	add_child(player)

	var layer := CanvasLayer.new()
	add_child(layer)
	ui = Control.new()
	ui.theme = UIKit.make_theme()
	ui.mouse_filter = Control.MOUSE_FILTER_IGNORE
	layer.add_child(ui)
	ui.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	controls = TouchControls.new()
	ui.add_child(controls)
	controls.menu_pressed.connect(_pause)
	player.controls = controls

	var title := UIKit.label("TRAINING RANGE", 22, UIKit.MUTED)
	title.set_anchors_and_offsets_preset(Control.PRESET_CENTER_TOP)
	title.offset_top = 12
	title.mouse_filter = Control.MOUSE_FILTER_IGNORE
	ui.add_child(title)
	stance_label = UIKit.label("", 26, UIKit.ACCENT)
	stance_label.set_anchors_and_offsets_preset(Control.PRESET_CENTER_BOTTOM)
	stance_label.offset_top = -48
	stance_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	ui.add_child(stance_label)
	GameSettings.apply()


func _process(_delta: float) -> void:
	stance_label.text = player.state_text()


func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST and not _paused:
		_pause()


# ---------- pause ----------

func _pause() -> void:
	if _paused:
		return
	_paused = true
	get_tree().paused = true
	controls.reset()
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 12)
	var settings := UIKit.button("SETTINGS")
	settings.pressed.connect(func() -> void:
		UIKit.show_modal(ui, "SETTINGS", SettingsPanel.new()))
	v.add_child(settings)
	var leave := UIKit.button("EXIT TO LOBBY")
	leave.pressed.connect(func() -> void:
		get_tree().paused = false
		get_tree().change_scene_to_file("res://scenes/lobby.tscn"))
	v.add_child(leave)
	UIKit.show_modal(ui, "PAUSED", v, "RESUME", _resume)


func _resume() -> void:
	_paused = false
	get_tree().paused = false
	controls.reset()


# ---------- world building ----------

func _make_grid_texture() -> ImageTexture:
	var n := 64
	var img := Image.create(n, n, false, Image.FORMAT_RGBA8)
	img.fill(Color(0.8, 0.8, 0.8))
	for i in n:
		for t in 2:
			img.set_pixel(i, t, Color(0.45, 0.45, 0.45))
			img.set_pixel(t, i, Color(0.45, 0.45, 0.45))
	img.generate_mipmaps()
	return ImageTexture.create_from_image(img)


func _mat(color: Color) -> StandardMaterial3D:
	var key := color.to_html()
	if _mats.has(key):
		return _mats[key]
	var m := StandardMaterial3D.new()
	m.albedo_color = color
	m.albedo_texture = _grid_tex
	m.uv1_triplanar = true
	m.uv1_scale = Vector3(0.5, 0.5, 0.5)
	m.texture_filter = BaseMaterial3D.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS_ANISOTROPIC
	m.roughness = 0.9
	_mats[key] = m
	return m


func _box(pos: Vector3, size: Vector3, color: Color, rot_deg: Vector3 = Vector3.ZERO) -> void:
	var body := StaticBody3D.new()
	body.position = pos
	body.rotation_degrees = rot_deg
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = size
	mi.mesh = bm
	mi.material_override = _mat(color)
	var cs := CollisionShape3D.new()
	var bs := BoxShape3D.new()
	bs.size = size
	cs.shape = bs
	body.add_child(mi)
	body.add_child(cs)
	add_child(body)


func _label3d(text: String, pos: Vector3, size: int = 96) -> void:
	var l := Label3D.new()
	l.text = text
	l.position = pos
	l.pixel_size = 0.01
	l.font_size = size
	l.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	l.modulate = Color(1, 0.85, 0.3)
	l.outline_size = 12
	add_child(l)


func _dummy(pos: Vector3) -> void:
	var body := StaticBody3D.new()
	body.position = pos
	var mat := StandardMaterial3D.new()
	mat.albedo_color = Color(0.9, 0.35, 0.12)
	var torso := MeshInstance3D.new()
	var cm := CapsuleMesh.new()
	cm.radius = 0.25
	cm.height = 1.5
	torso.mesh = cm
	torso.material_override = mat
	torso.position.y = 0.75
	body.add_child(torso)
	var head := MeshInstance3D.new()
	var sm := SphereMesh.new()
	sm.radius = 0.15
	sm.height = 0.3
	head.mesh = sm
	head.material_override = mat
	head.position.y = 1.65
	body.add_child(head)
	var cs := CollisionShape3D.new()
	var cap := CapsuleShape3D.new()
	cap.radius = 0.25
	cap.height = 1.8
	cs.shape = cap
	cs.position.y = 0.9
	body.add_child(cs)
	add_child(body)


func _build_environment() -> void:
	var sky_mat := ProceduralSkyMaterial.new()
	sky_mat.sky_top_color = Color(0.25, 0.45, 0.75)
	sky_mat.sky_horizon_color = Color(0.7, 0.8, 0.9)
	sky_mat.ground_horizon_color = Color(0.7, 0.8, 0.9)
	sky_mat.ground_bottom_color = Color(0.2, 0.25, 0.3)
	var sky := Sky.new()
	sky.sky_material = sky_mat
	var env := Environment.new()
	env.background_mode = Environment.BG_SKY
	env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	env.fog_enabled = true
	env.fog_light_color = Color(0.7, 0.8, 0.9)
	env.fog_density = 0.004
	var we := WorldEnvironment.new()
	we.environment = env
	add_child(we)
	var sun := DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-55, -35, 0)
	sun.light_energy = 1.1
	sun.shadow_enabled = bool(GameSettings.values["shadows"])
	sun.directional_shadow_mode = DirectionalLight3D.SHADOW_ORTHOGONAL
	sun.directional_shadow_max_distance = 50.0
	sun.add_to_group("sun")
	add_child(sun)


func _build_world() -> void:
	var ground := Color(0.55, 0.6, 0.55)
	var concrete := Color(0.62, 0.62, 0.65)
	var crate := Color(0.5, 0.38, 0.22)
	var wall := Color(0.45, 0.5, 0.55)
	# Ground and boundary walls
	_box(Vector3(0, -0.5, -30), Vector3(80, 1, 140), ground)
	_box(Vector3(0, 4, -100), Vector3(80, 8, 1), wall)
	_box(Vector3(0, 4, 40.5), Vector3(80, 8, 1), wall)
	_box(Vector3(40.5, 4, -30), Vector3(1, 8, 141), wall)
	_box(Vector3(-40.5, 4, -30), Vector3(1, 8, 141), wall)
	_label3d("TRAINING RANGE", Vector3(0, 2.6, -4), 120)
	# Distance markers
	var strip := StandardMaterial3D.new()
	strip.albedo_color = Color(1, 0.8, 0.2)
	strip.emission_enabled = true
	strip.emission = Color(1, 0.8, 0.2)
	for d in range(10, 90, 10):
		var mi := MeshInstance3D.new()
		var bm := BoxMesh.new()
		bm.size = Vector3(8, 0.02, 0.25)
		mi.mesh = bm
		mi.material_override = strip
		mi.position = Vector3(0, 0.012, -d)
		add_child(mi)
		_label3d("%d m" % d, Vector3(-5, 1.3, -d))
	# Cover of different heights (walk / crouch behind)
	_box(Vector3(-3, 0.3, -8), Vector3(1.6, 0.6, 0.6), crate)
	_box(Vector3(2.5, 0.5, -10), Vector3(1.6, 1.0, 0.6), crate)
	_box(Vector3(-1, 0.75, -14), Vector3(2.2, 1.5, 0.6), concrete)
	_box(Vector3(4, 1.1, -18), Vector3(2.0, 2.2, 0.6), concrete)
	# Stairs to a platform (left)
	for i in 6:
		var h := 0.25 * (i + 1)
		_box(Vector3(-14, h / 2.0, -10.6 - i * 0.8), Vector3(4, h, 0.8), concrete)
	_box(Vector3(-14, 0.75, -18), Vector3(6, 1.5, 6), concrete)
	_label3d("STAIRS", Vector3(-14, 2.6, -9))
	# Ramp to a high platform (right)
	_box(Vector3(12, 1.0, -12), Vector3(4, 0.3, 8), concrete, Vector3(15, 0, 0))
	_box(Vector3(12, 1.0, -19), Vector3(4, 2.0, 6), concrete)
	_label3d("RAMP", Vector3(12, 3.4, -9))
	# Jump course
	_box(Vector3(-24, 0.25, -8), Vector3(3, 0.5, 3), crate)
	_box(Vector3(-24, 0.5, -13), Vector3(3, 1.0, 3), crate)
	_box(Vector3(-24, 0.75, -18), Vector3(3, 1.5, 3), crate)
	_box(Vector3(-24, 1.0, -23), Vector3(3, 2.0, 3), crate)
	_label3d("JUMP COURSE", Vector3(-24, 3.4, -5))
	# Crouch tunnel (too low to walk under standing)
	_box(Vector3(6.4, 1.0, -6), Vector3(0.4, 2.0, 1.4), concrete)
	_box(Vector3(9.6, 1.0, -6), Vector3(0.4, 2.0, 1.4), concrete)
	_box(Vector3(8, 1.7, -6), Vector3(3.2, 0.6, 1.4), concrete)
	_label3d("CROUCH", Vector3(8, 3.0, -6))
	# Enterable hut with door and window
	var hx := -12.0
	var hz := -35.0
	_box(Vector3(hx - 2.5, 1.5, hz + 4), Vector3(3, 3, 0.3), wall)
	_box(Vector3(hx + 2.5, 1.5, hz + 4), Vector3(3, 3, 0.3), wall)
	_box(Vector3(hx, 2.6, hz + 4), Vector3(2, 0.8, 0.3), wall)
	_box(Vector3(hx, 1.5, hz - 4), Vector3(8, 3, 0.3), wall)
	_box(Vector3(hx - 4, 1.5, hz), Vector3(0.3, 3, 8), wall)
	_box(Vector3(hx + 4, 1.5, hz - 2.75), Vector3(0.3, 3, 2.5), wall)
	_box(Vector3(hx + 4, 1.5, hz + 2.75), Vector3(0.3, 3, 2.5), wall)
	_box(Vector3(hx + 4, 0.5, hz), Vector3(0.3, 1.0, 3), wall)
	_box(Vector3(hx + 4, 2.6, hz), Vector3(0.3, 0.8, 3), wall)
	_box(Vector3(hx, 3.1, hz), Vector3(8.4, 0.2, 8.4), concrete)
	_box(Vector3(hx - 2.5, 0.5, hz - 2.5), Vector3(1, 1, 1), crate)
	_label3d("HUT", Vector3(hx, 4.2, hz + 4))
	# Target dummies (scenery for now; shooting arrives in Phase 2)
	for p in [Vector3(-4, 0, -25), Vector3(3, 0, -35), Vector3(-2, 0, -45), Vector3(6, 0, -55), Vector3(0, 0, -65)]:
		_dummy(p)
