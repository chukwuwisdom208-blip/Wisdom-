extends Control
## Startup animation: logo, subtitle, then login (or straight to lobby if "remember me" is set).

const UIKit = preload("res://scripts/ui/ui_kit.gd")

var _done := false
var _title: Label


func _ready() -> void:
	theme = UIKit.make_theme()
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var bg := ColorRect.new()
	bg.color = UIKit.BG
	bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(bg)
	var center := CenterContainer.new()
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(center)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 14)
	v.alignment = BoxContainer.ALIGNMENT_CENTER
	center.add_child(v)
	_title = UIKit.label("WARZONE LITE", 96, UIKit.TEXT)
	_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_title.modulate.a = 0.0
	v.add_child(_title)
	var line := ColorRect.new()
	line.color = UIKit.ACCENT
	line.custom_minimum_size = Vector2(0, 5)
	line.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	v.add_child(line)
	var sub := UIKit.label("OPERATION: LAST DOMINION", 34, UIKit.ACCENT)
	sub.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	sub.modulate.a = 0.0
	v.add_child(sub)
	var hint := UIKit.label("TAP TO SKIP", 18, UIKit.MUTED)
	hint.set_anchors_and_offsets_preset(Control.PRESET_CENTER_BOTTOM)
	hint.offset_top = -50
	add_child(hint)

	var tw := create_tween()
	tw.tween_property(_title, "modulate:a", 1.0, 0.9)
	tw.parallel().tween_property(line, "custom_minimum_size:x", 560.0, 0.9)
	tw.tween_property(sub, "modulate:a", 1.0, 0.7)
	tw.tween_interval(1.0)
	tw.tween_callback(_go)

	await get_tree().process_frame
	_title.pivot_offset = _title.size / 2.0
	_title.scale = Vector2(1.15, 1.15)
	create_tween().tween_property(_title, "scale", Vector2.ONE, 1.4).set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_OUT)


func _input(event: InputEvent) -> void:
	if (event is InputEventScreenTouch and event.pressed) or (event is InputEventMouseButton and event.pressed):
		_go()


func _go() -> void:
	if _done:
		return
	_done = true
	if Auth.try_auto_login():
		get_tree().change_scene_to_file("res://scenes/lobby.tscn")
	else:
		get_tree().change_scene_to_file("res://scenes/login.tscn")
