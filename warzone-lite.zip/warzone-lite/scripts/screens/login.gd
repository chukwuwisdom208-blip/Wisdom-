extends Control
## Login: sign in, create account, guest, remember me, recovery (via recovery code).

const UIKit = preload("res://scripts/ui/ui_kit.gd")

var form: VBoxContainer
var msg: Label
var f_user: LineEdit
var f_pass: LineEdit
var f_confirm: LineEdit
var f_code: LineEdit
var f_remember: CheckBox
var mode := 0


func _ready() -> void:
	theme = UIKit.make_theme()
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var bg := ColorRect.new()
	bg.color = UIKit.BG
	bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(bg)
	var center := CenterContainer.new()
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(center)
	var panel := PanelContainer.new()
	panel.custom_minimum_size = Vector2(640, 0)
	center.add_child(panel)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 12)
	panel.add_child(v)
	var title := UIKit.label("WARZONE LITE", 48)
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	v.add_child(title)
	var sub := UIKit.label("OPERATION: LAST DOMINION", 20, UIKit.ACCENT)
	sub.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	v.add_child(sub)
	var tabs := UIKit.segmented(["SIGN IN", "CREATE ACCOUNT", "RECOVER"], 0, _set_mode)
	tabs.alignment = BoxContainer.ALIGNMENT_CENTER
	v.add_child(tabs)
	form = VBoxContainer.new()
	form.add_theme_constant_override("separation", 10)
	v.add_child(form)
	msg = UIKit.label("", 20, UIKit.BAD)
	msg.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	msg.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	v.add_child(msg)
	var guest := UIKit.button("PLAY AS GUEST (OFFLINE)")
	guest.pressed.connect(func() -> void:
		Auth.guest_login()
		_enter())
	v.add_child(guest)
	var note := UIKit.label("Accounts are stored on this device only.", 16, UIKit.MUTED)
	note.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	v.add_child(note)
	_set_mode(0)


func _field(placeholder: String, secret: bool = false) -> LineEdit:
	var e := LineEdit.new()
	e.placeholder_text = placeholder
	e.secret = secret
	e.custom_minimum_size = Vector2(0, 60)
	form.add_child(e)
	return e


func _set_mode(i: int) -> void:
	mode = i
	msg.text = ""
	msg.add_theme_color_override("font_color", UIKit.BAD)
	for c in form.get_children():
		form.remove_child(c)
		c.queue_free()
	f_confirm = null
	f_code = null
	f_remember = null
	f_user = _field("Username")
	if i == 0:
		f_pass = _field("Password", true)
		_add_remember()
		_add_submit("SIGN IN", _do_signin)
	elif i == 1:
		f_pass = _field("Password (min 6 characters)", true)
		f_confirm = _field("Confirm password", true)
		_add_remember()
		_add_submit("CREATE ACCOUNT", _do_create)
	else:
		f_code = _field("Recovery code (XXXX-XXXX)")
		f_pass = _field("New password", true)
		_add_submit("RESET PASSWORD", _do_recover)


func _add_remember() -> void:
	f_remember = CheckBox.new()
	f_remember.text = "Remember me"
	f_remember.custom_minimum_size = Vector2(0, 50)
	f_remember.focus_mode = Control.FOCUS_NONE
	form.add_child(f_remember)


func _add_submit(text: String, cb: Callable) -> void:
	var b := UIKit.button(text, true)
	b.pressed.connect(cb)
	form.add_child(b)


func _enter() -> void:
	get_tree().change_scene_to_file("res://scenes/lobby.tscn")


func _do_signin() -> void:
	var r := Auth.sign_in(f_user.text, f_pass.text, f_remember.button_pressed)
	if r["ok"]:
		_enter()
	else:
		msg.text = r["error"]


func _do_create() -> void:
	if f_pass.text != f_confirm.text:
		msg.text = "Passwords do not match."
		return
	var r := Auth.create_account(f_user.text, f_pass.text, f_remember.button_pressed)
	if not r["ok"]:
		msg.text = r["error"]
		return
	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 16)
	var info := UIKit.label("Write this recovery code down. It is the ONLY way to reset your password on this device.", 22)
	info.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	box.add_child(info)
	var code := UIKit.label(str(r["code"]), 64, UIKit.ACCENT)
	code.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	box.add_child(code)
	UIKit.show_modal(self, "ACCOUNT CREATED", box, "I'VE SAVED IT", _enter)


func _do_recover() -> void:
	var r := Auth.recover(f_user.text, f_code.text, f_pass.text)
	if r["ok"]:
		_set_mode(0)
		msg.add_theme_color_override("font_color", UIKit.GOOD)
		msg.text = "Password reset. You can sign in now."
	else:
		msg.add_theme_color_override("font_color", UIKit.BAD)
		msg.text = r["error"]
