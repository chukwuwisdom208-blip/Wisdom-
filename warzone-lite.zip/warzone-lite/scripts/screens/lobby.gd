extends Control
## Main lobby: animated 3D operator, profile card, level + rank bars, gold, menu buttons.

const UIKit = preload("res://scripts/ui/ui_kit.gd")
const AvatarBadge = preload("res://scripts/ui/avatar_badge.gd")
const SettingsPanel = preload("res://scripts/ui/settings_panel.gd")
const LobbyStage = preload("res://scripts/lobby/lobby_stage.gd")
const OperatorModel = preload("res://scripts/entities/operator_model.gd")
const RankSystem = preload("res://scripts/systems/rank_system.gd")
const LevelSystem = preload("res://scripts/systems/level_system.gd")

var profile: Dictionary
var stage: Node3D
var avatar: Control
var name_label: Label
var id_label: Label
var level_label: Label
var xp_label: Label
var level_bar: ProgressBar
var rank_label: Label
var rank_pts_label: Label
var rank_bar: ProgressBar
var gold_label: Label
var dev_box: Control


func _ready() -> void:
	theme = UIKit.make_theme()
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	profile = Auth.get_profile()
	if profile.is_empty():
		get_tree().call_deferred("change_scene_to_file", "res://scenes/login.tscn")
		return
	_build_stage()
	var margin := MarginContainer.new()
	margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	for side in ["left", "right", "top", "bottom"]:
		margin.add_theme_constant_override("margin_" + side, 24)
	add_child(margin)
	var hb := HBoxContainer.new()
	hb.add_theme_constant_override("separation", 20)
	margin.add_child(hb)
	hb.add_child(_build_left())
	var center := Control.new()
	center.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	center.mouse_filter = Control.MOUSE_FILTER_STOP
	center.gui_input.connect(_on_center_input)
	var hint := UIKit.label("TAP THE OPERATOR", 18, UIKit.MUTED)
	hint.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_WIDE)
	hint.offset_top = -40
	hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	hint.mouse_filter = Control.MOUSE_FILTER_IGNORE
	center.add_child(hint)
	hb.add_child(center)
	hb.add_child(_build_right())
	_refresh_texts()
	_init_bars()
	GameSettings.changed.connect(_on_settings_changed)
	GameSettings.apply()


func _build_stage() -> void:
	var svc := SubViewportContainer.new()
	svc.stretch = true
	svc.mouse_filter = Control.MOUSE_FILTER_IGNORE
	svc.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(svc)
	var vp := SubViewport.new()
	vp.own_world_3d = true
	vp.add_to_group("viewport3d")
	svc.add_child(vp)
	stage = LobbyStage.new()
	vp.add_child(stage)
	_apply_look()


func _apply_look() -> void:
	stage.set_operator_colors(int(profile["suit_color"]), int(profile["accent_color"]))


func _make_bar(h: int) -> ProgressBar:
	var b := ProgressBar.new()
	b.show_percentage = false
	b.custom_minimum_size = Vector2(0, h)
	return b


func _build_left() -> Control:
	var panel := PanelContainer.new()
	panel.custom_minimum_size = Vector2(400, 0)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 12)
	panel.add_child(v)
	var top := HBoxContainer.new()
	top.add_theme_constant_override("separation", 16)
	avatar = AvatarBadge.new()
	top.add_child(avatar)
	var names := VBoxContainer.new()
	names.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	name_label = UIKit.label("", 30)
	id_label = UIKit.label("", 18, UIKit.MUTED)
	names.add_child(name_label)
	names.add_child(id_label)
	top.add_child(names)
	v.add_child(top)
	level_label = UIKit.label("", 26)
	v.add_child(level_label)
	level_bar = _make_bar(18)
	v.add_child(level_bar)
	xp_label = UIKit.label("", 18, UIKit.MUTED)
	v.add_child(xp_label)
	v.add_child(HSeparator.new())
	v.add_child(UIKit.label("COMPETITIVE RANK", 18, UIKit.MUTED))
	rank_label = UIKit.label("", 34)
	v.add_child(rank_label)
	rank_bar = _make_bar(22)
	v.add_child(rank_bar)
	rank_pts_label = UIKit.label("", 18, UIKit.MUTED)
	v.add_child(rank_pts_label)
	v.add_child(HSeparator.new())
	gold_label = UIKit.label("", 28, UIKit.ACCENT)
	v.add_child(gold_label)
	return panel


func _build_right() -> Control:
	var panel := PanelContainer.new()
	panel.custom_minimum_size = Vector2(340, 0)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 10)
	panel.add_child(v)
	var play := UIKit.button("PLAY MATCH  (Phase 3)")
	play.disabled = true
	v.add_child(play)
	var range_btn := UIKit.button("TRAINING RANGE", true)
	range_btn.pressed.connect(func() -> void:
		get_tree().change_scene_to_file("res://scenes/range.tscn"))
	v.add_child(range_btn)
	var op := UIKit.button("OPERATOR LOOK")
	op.pressed.connect(_open_operator)
	v.add_child(op)
	var prof := UIKit.button("PROFILE & STATS")
	prof.pressed.connect(_open_profile)
	v.add_child(prof)
	var st := UIKit.button("SETTINGS")
	st.pressed.connect(func() -> void:
		UIKit.show_modal(self, "SETTINGS", SettingsPanel.new()))
	v.add_child(st)
	var out := UIKit.button("SIGN OUT")
	out.pressed.connect(func() -> void:
		Auth.sign_out()
		get_tree().change_scene_to_file("res://scenes/login.tscn"))
	v.add_child(out)
	dev_box = VBoxContainer.new()
	dev_box.add_child(UIKit.label("DEV TOOLS", 16, UIKit.MUTED))
	var grid := GridContainer.new()
	grid.columns = 2
	grid.add_theme_constant_override("h_separation", 8)
	grid.add_theme_constant_override("v_separation", 8)
	var tools := [["+100 XP", 0, 100], ["+1500 XP", 0, 1500], ["+60 RANK", 1, 60], ["-60 RANK", 1, -60], ["+500 GOLD", 2, 500]]
	for t in tools:
		var b := UIKit.button(str(t[0]))
		b.custom_minimum_size = Vector2(0, 48)
		b.pressed.connect(_dev.bind(int(t[1]), int(t[2])))
		grid.add_child(b)
	dev_box.add_child(grid)
	dev_box.visible = bool(GameSettings.values["dev_tools"])
	v.add_child(dev_box)
	return panel


func _on_settings_changed() -> void:
	if dev_box != null:
		dev_box.visible = bool(GameSettings.values["dev_tools"])


func _on_center_input(event: InputEvent) -> void:
	if event is InputEventMouseButton and event.pressed:
		stage.operator.salute()


# ---------- stats display ----------

func _refresh_texts() -> void:
	name_label.text = str(profile["username"])
	id_label.text = "ID: " + str(profile["player_id"])
	avatar.setup(int(profile["avatar"]), str(profile["username"]), 96)
	var lvl := int(profile["level"])
	level_label.text = "LEVEL %d" % lvl
	if lvl >= LevelSystem.max_level():
		xp_label.text = "MAX LEVEL"
	else:
		xp_label.text = "%d / %d XP" % [int(profile["xp"]), LevelSystem.xp_to_next(lvl)]
	var ri := int(profile["rank_index"])
	rank_label.text = RankSystem.rank_name(ri)
	var col := RankSystem.tier_color(ri)
	rank_label.add_theme_color_override("font_color", col)
	rank_bar.add_theme_stylebox_override("fill", UIKit.sb(col, Color(0, 0, 0, 0), 8, 0, 0))
	rank_pts_label.text = "%d / %d pts" % [int(profile["rank_points"]), RankSystem.points_required(ri)]
	gold_label.text = "GOLD  %s" % _commas(int(profile["gold"]))


func _commas(n: int) -> String:
	var s := str(absi(n))
	var out := ""
	for i in s.length():
		if i > 0 and (s.length() - i) % 3 == 0:
			out += ","
		out += s[i]
	return ("-" if n < 0 else "") + out


func _init_bars() -> void:
	var lvl := int(profile["level"])
	level_bar.max_value = LevelSystem.xp_to_next(lvl)
	level_bar.value = level_bar.max_value if lvl >= LevelSystem.max_level() else float(profile["xp"])
	var ri := int(profile["rank_index"])
	rank_bar.max_value = RankSystem.points_required(ri)
	rank_bar.value = float(profile["rank_points"])


func _snapshot() -> Dictionary:
	return {"level": int(profile["level"]), "xp": int(profile["xp"]),
			"rank": int(profile["rank_index"]), "pts": int(profile["rank_points"])}


func _animate_progress(bar: ProgressBar, old_idx: int, new_idx: int, new_val: int, req: Callable) -> void:
	var tw := create_tween()
	if new_idx == old_idx:
		bar.max_value = req.call(new_idx)
		tw.tween_property(bar, "value", float(new_val), 0.6)
	elif new_idx > old_idx:
		tw.tween_property(bar, "value", bar.max_value, 0.5)
		tw.tween_callback(func() -> void:
			bar.max_value = req.call(new_idx)
			bar.value = 0.0)
		tw.tween_property(bar, "value", float(new_val), 0.6)
	else:
		tw.tween_property(bar, "value", 0.0, 0.4)
		tw.tween_callback(func() -> void:
			bar.max_value = req.call(new_idx)
			bar.value = bar.max_value)
		tw.tween_property(bar, "value", float(new_val), 0.6)


func _after_change(before: Dictionary) -> void:
	SaveSystem.save()
	var now := _snapshot()
	_refresh_texts()
	var xp_target: int = now["xp"]
	if now["level"] >= LevelSystem.max_level():
		xp_target = LevelSystem.xp_to_next(now["level"])
	_animate_progress(level_bar, before["level"], now["level"], xp_target,
			func(i: int) -> int: return LevelSystem.xp_to_next(i))
	_animate_progress(rank_bar, before["rank"], now["rank"], now["pts"],
			func(i: int) -> int: return RankSystem.points_required(i))
	if now["level"] > before["level"]:
		UIKit.toast(self, "LEVEL UP!  LEVEL %d" % now["level"], UIKit.ACCENT)
	if now["rank"] > before["rank"]:
		UIKit.toast(self, "PROMOTED  " + RankSystem.rank_name(now["rank"]), RankSystem.tier_color(now["rank"]))
	elif now["rank"] < before["rank"]:
		UIKit.toast(self, "DEMOTED  " + RankSystem.rank_name(now["rank"]), UIKit.BAD)


func _dev(kind: int, amount: int) -> void:
	var before := _snapshot()
	if kind == 0:
		LevelSystem.add_xp(profile, amount)
	elif kind == 1:
		RankSystem.add_points(profile, amount)
	else:
		profile["gold"] = int(profile["gold"]) + amount
	_after_change(before)


# ---------- overlays ----------

func _fill_swatches(row: HBoxContainer, palette: Array, key: String) -> void:
	for c in row.get_children():
		row.remove_child(c)
		c.queue_free()
	for i in palette.size():
		var b := Button.new()
		b.custom_minimum_size = Vector2(72, 72)
		b.focus_mode = Control.FOCUS_NONE
		var selected := int(profile[key]) == i
		var st := UIKit.sb(palette[i], Color.WHITE if selected else UIKit.BORDER, 36, 5 if selected else 2, 0)
		for state in ["normal", "hover", "pressed", "focus"]:
			b.add_theme_stylebox_override(state, st)
		b.pressed.connect(_on_swatch.bind(row, palette, key, i))
		row.add_child(b)


func _on_swatch(row: HBoxContainer, palette: Array, key: String, i: int) -> void:
	profile[key] = i
	SaveSystem.save()
	_apply_look()
	_refresh_texts()
	_fill_swatches.call_deferred(row, palette, key)


func _swatch_row(palette: Array, key: String) -> HBoxContainer:
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 14)
	_fill_swatches(row, palette, key)
	return row


func _open_operator() -> void:
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 14)
	v.add_child(UIKit.section("SUIT COLOUR"))
	v.add_child(_swatch_row(OperatorModel.SUIT_COLORS, "suit_color"))
	v.add_child(UIKit.section("ACCENT / VISOR COLOUR"))
	v.add_child(_swatch_row(OperatorModel.ACCENT_COLORS, "accent_color"))
	UIKit.show_modal(self, "OPERATOR LOOK", v)


func _open_profile() -> void:
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 14)
	v.add_child(UIKit.section("AVATAR"))
	v.add_child(_swatch_row(AvatarBadge.COLORS, "avatar"))
	v.add_child(UIKit.section("STATS"))
	var kd := float(profile["eliminations"]) / maxf(float(profile["deaths"]), 1.0)
	var rows := [
		["Username", str(profile["username"])],
		["Player ID", str(profile["player_id"])],
		["Level", str(profile["level"])],
		["Rank", RankSystem.rank_name(int(profile["rank_index"]))],
		["Total matches", str(profile["matches"])],
		["Wins", str(profile["wins"])],
		["Eliminations", str(profile["eliminations"])],
		["K/D ratio", "%.2f" % kd],
		["Favourite mode", str(profile["fav_mode"])],
	]
	var grid := GridContainer.new()
	grid.columns = 2
	grid.add_theme_constant_override("h_separation", 60)
	grid.add_theme_constant_override("v_separation", 8)
	for r in rows:
		grid.add_child(UIKit.label(r[0], 22, UIKit.MUTED))
		grid.add_child(UIKit.label(r[1], 22))
	v.add_child(grid)
	UIKit.show_modal(self, "PROFILE", v)
