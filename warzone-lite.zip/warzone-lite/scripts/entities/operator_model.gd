extends Node3D
## Procedural low-poly operator built from primitives (no external assets, ~0 KB).
## Placeholder art for Phase 1; real operator models/animations come in Phase 6.

const SUIT_COLORS: Array[Color] = [
	Color(0.29, 0.34, 0.22), Color(0.14, 0.20, 0.34), Color(0.16, 0.17, 0.19),
	Color(0.62, 0.54, 0.38), Color(0.45, 0.12, 0.14), Color(0.80, 0.84, 0.88)]
const ACCENT_COLORS: Array[Color] = [
	Color(0.95, 0.66, 0.0), Color(0.0, 0.85, 0.95), Color(0.55, 0.95, 0.2),
	Color(0.95, 0.2, 0.8), Color(1.0, 0.4, 0.1), Color(1.0, 1.0, 1.0)]

var suit_mat: StandardMaterial3D
var accent_mat: StandardMaterial3D
var skin_mat: StandardMaterial3D
var dark_mat: StandardMaterial3D
var hips: Node3D
var spine: Node3D
var head: Node3D
var arm_l: Node3D
var arm_r: Node3D
var _saluting := false


func _ready() -> void:
	suit_mat = _mat(SUIT_COLORS[0], 0.1, 0.7)
	skin_mat = _mat(Color(0.72, 0.55, 0.45), 0.0, 0.8)
	dark_mat = _mat(Color(0.07, 0.07, 0.08), 0.2, 0.6)
	accent_mat = _mat(ACCENT_COLORS[0], 0.0, 0.4)
	accent_mat.emission_enabled = true
	accent_mat.emission = ACCENT_COLORS[0]
	accent_mat.emission_energy_multiplier = 1.5
	_build()


func _mat(c: Color, metallic: float, rough: float) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = c
	m.metallic = metallic
	m.roughness = rough
	return m


func _box(parent: Node3D, size: Vector3, pos: Vector3, mat: Material) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = size
	mi.mesh = bm
	mi.material_override = mat
	mi.position = pos
	parent.add_child(mi)
	return mi


func _ball(parent: Node3D, radius: float, pos: Vector3, scl: Vector3, mat: Material) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var sm := SphereMesh.new()
	sm.radius = radius
	sm.height = radius * 2.0
	sm.radial_segments = 16
	sm.rings = 8
	mi.mesh = sm
	mi.material_override = mat
	mi.position = pos
	mi.scale = scl
	parent.add_child(mi)
	return mi


func _limb(parent: Node3D, pivot_pos: Vector3, size: Vector3, mat: Material) -> Node3D:
	var pivot := Node3D.new()
	pivot.position = pivot_pos
	parent.add_child(pivot)
	_box(pivot, size, Vector3(0, -size.y / 2.0, 0), mat)
	return pivot


func _build() -> void:
	hips = Node3D.new()
	hips.position = Vector3(0, 0.95, 0)
	add_child(hips)
	for sx in [-0.13, 0.13]:
		var leg := _limb(hips, Vector3(sx, 0, 0), Vector3(0.18, 0.9, 0.22), suit_mat)
		_box(leg, Vector3(0.2, 0.14, 0.32), Vector3(0, -0.88, 0.05), dark_mat)
	spine = Node3D.new()
	spine.position = Vector3(0, 0.05, 0)
	hips.add_child(spine)
	_box(spine, Vector3(0.5, 0.62, 0.3), Vector3(0, 0.33, 0), suit_mat)
	_box(spine, Vector3(0.34, 0.26, 0.06), Vector3(0, 0.42, 0.17), accent_mat)
	_box(spine, Vector3(0.52, 0.07, 0.32), Vector3(0, 0.04, 0), dark_mat)
	head = Node3D.new()
	head.position = Vector3(0, 0.68, 0)
	spine.add_child(head)
	_ball(head, 0.13, Vector3(0, 0.15, 0), Vector3.ONE, skin_mat)
	_ball(head, 0.16, Vector3(0, 0.19, -0.005), Vector3(1.0, 0.85, 1.05), suit_mat)
	_box(head, Vector3(0.24, 0.07, 0.06), Vector3(0, 0.17, 0.13), accent_mat)
	arm_l = _limb(spine, Vector3(-0.34, 0.62, 0), Vector3(0.12, 0.58, 0.14), suit_mat)
	arm_r = _limb(spine, Vector3(0.34, 0.62, 0), Vector3(0.12, 0.58, 0.14), suit_mat)
	_box(arm_l, Vector3(0.1, 0.1, 0.1), Vector3(0, -0.6, 0), skin_mat)
	_box(arm_r, Vector3(0.1, 0.1, 0.1), Vector3(0, -0.6, 0), skin_mat)


func set_colors(suit_idx: int, accent_idx: int) -> void:
	var s: Color = SUIT_COLORS[suit_idx % SUIT_COLORS.size()]
	var a: Color = ACCENT_COLORS[accent_idx % ACCENT_COLORS.size()]
	suit_mat.albedo_color = s
	accent_mat.albedo_color = a
	accent_mat.emission = a


func idle(t: float) -> void:
	var b := sin(t * 1.6)
	hips.position.y = 0.95 + b * 0.008
	spine.rotation.x = b * 0.02
	head.rotation.y = sin(t * 0.45) * 0.35
	head.rotation.x = sin(t * 0.3) * 0.05
	arm_l.rotation.z = -0.10 - b * 0.02
	if not _saluting:
		arm_r.rotation.z = 0.10 + b * 0.02
	rotation.y = sin(t * 0.25) * 0.25


func salute() -> void:
	if _saluting:
		return
	_saluting = true
	arm_r.rotation.z = 0.15
	var tw := create_tween()
	tw.tween_property(arm_r, "rotation:x", -2.7, 0.35)
	tw.tween_property(arm_r, "rotation:x", -2.3, 0.18)
	tw.tween_property(arm_r, "rotation:x", -2.9, 0.18)
	tw.tween_property(arm_r, "rotation:x", -2.3, 0.18)
	tw.tween_property(arm_r, "rotation:x", 0.0, 0.4)
	tw.tween_callback(func() -> void: _saluting = false)
