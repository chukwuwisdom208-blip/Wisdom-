extends RefCounted
## Player level 1-100 (separate from competitive rank). Curve comes from res://data/progression.json.


static func max_level() -> int:
	return int(GameData.progression_config.get("max_level", 100))


static func xp_to_next(level: int) -> int:
	if level >= max_level():
		return 1
	var c: Dictionary = GameData.progression_config
	var v := float(c.get("xp_base", 80)) + float(c.get("xp_linear", 25)) * level \
			+ float(c.get("xp_quadratic", 0.6)) * level * level
	return int(round(v))


## Returns how many levels were gained.
static func add_xp(profile: Dictionary, amount: int) -> int:
	var lvl := int(profile["level"])
	var xp := int(profile["xp"]) + amount
	var gained := 0
	while lvl < max_level() and xp >= xp_to_next(lvl):
		xp -= xp_to_next(lvl)
		lvl += 1
		gained += 1
	if lvl >= max_level():
		xp = 0
	profile["level"] = lvl
	profile["xp"] = xp
	return gained
