extends RefCounted
## Competitive rank logic. All numbers come from res://data/ranks.json.
## Division index 0 = Gold IV, 1 = Gold III ... 23 = Mythic I, 24+ = Mythic +1, +2 ...


static func _cfg() -> Dictionary:
	return GameData.ranks_config


static func divisions_per_tier() -> int:
	return int(_cfg().get("divisions_per_tier", 4))


static func named_division_count() -> int:
	return (_cfg().get("tiers", []) as Array).size() * divisions_per_tier()


static func points_required(index: int) -> int:
	var overrides: Dictionary = _cfg().get("points_overrides", {})
	if overrides.has(str(index)):
		return int(overrides[str(index)])
	return int(_cfg().get("points_base", 100)) + int(_cfg().get("points_step", 100)) * index


static func rank_name(index: int) -> String:
	var tiers: Array = _cfg().get("tiers", [])
	var labels: Array = _cfg().get("division_labels", ["IV", "III", "II", "I"])
	var per := divisions_per_tier()
	if index >= named_division_count():
		return "%s%d" % [str(_cfg().get("overflow_label", "Mythic +")), index - named_division_count() + 1]
	var tier: Dictionary = tiers[int(floor(float(index) / per))]
	return "%s %s" % [tier["name"], labels[index % per]]


static func tier_color(index: int) -> Color:
	var tiers: Array = _cfg().get("tiers", [])
	var t := mini(int(floor(float(index) / divisions_per_tier())), tiers.size() - 1)
	return Color(str(tiers[t]["color"]))


## Adds (or subtracts) points. Handles promotion and demotion with carry-over.
static func add_points(profile: Dictionary, delta: int) -> Dictionary:
	var idx := int(profile["rank_index"])
	var pts := int(profile["rank_points"]) + delta
	var promoted := 0
	var demoted := 0
	while pts >= points_required(idx):
		pts -= points_required(idx)
		idx += 1
		promoted += 1
	while pts < 0:
		if idx == 0:
			pts = 0
			break
		idx -= 1
		pts += points_required(idx)
		demoted += 1
	profile["rank_index"] = idx
	profile["rank_points"] = pts
	return {"promoted": promoted, "demoted": demoted}
