extends Node
## Persistent settings. Every key here is actually used by the game.

signal changed

const PRESETS := {
	"low": {"shadows": false, "msaa": 0, "max_fps": 30},
	"medium": {"shadows": true, "msaa": 0, "max_fps": 60},
	"high": {"shadows": true, "msaa": 4, "max_fps": 60},
}
const PRESET_KEYS := ["shadows", "msaa", "max_fps"]
const DEFAULTS := {
	"graphics_preset": "medium",
	"shadows": true,
	"msaa": 0,
	"max_fps": 60,
	"show_fps": false,
	"look_sensitivity": 1.0,
	"fov": 75,
	"invert_y": false,
	"touch_opacity": 0.6,
	"touch_scale": 1.0,
	"dev_tools": false,
}

var values: Dictionary = {}
var _timer: Timer
var _fps_label: Label


func _ready() -> void:
	values = DEFAULTS.duplicate()
	var saved: Dictionary = SaveSystem.data.get("settings", {})
	for k in saved.keys():
		if values.has(k):
			values[k] = saved[k]
	if not saved.has("graphics_preset"):
		var rec := recommend_preset()
		values["graphics_preset"] = rec
		for k in PRESET_KEYS:
			values[k] = PRESETS[rec][k]
	values["msaa"] = int(values["msaa"])
	values["max_fps"] = int(values["max_fps"])
	values["fov"] = int(values["fov"])
	_timer = Timer.new()
	_timer.one_shot = true
	_timer.wait_time = 0.6
	_timer.timeout.connect(_flush)
	add_child(_timer)
	_make_fps_overlay()
	apply()


func _process(_delta: float) -> void:
	_fps_label.visible = bool(values["show_fps"])
	if _fps_label.visible:
		_fps_label.text = "%d FPS" % Engine.get_frames_per_second()


func recommend_preset() -> String:
	var cores := OS.get_processor_count()
	var mem: Dictionary = OS.get_memory_info()
	var phys := int(mem.get("physical", -1))
	var gb := -1.0
	if phys > 0:
		gb = phys / 1073741824.0
	if cores <= 4 or (gb > 0.0 and gb < 3.5):
		return "low"
	if cores >= 8 and (gb < 0.0 or gb >= 6.0):
		return "high"
	return "medium"


func set_value(key: String, value: Variant) -> void:
	values[key] = value
	if PRESET_KEYS.has(key):
		values["graphics_preset"] = "custom"
	_commit()


func apply_preset(preset: String) -> void:
	if not PRESETS.has(preset):
		return
	values["graphics_preset"] = preset
	for k in PRESET_KEYS:
		values[k] = PRESETS[preset][k]
	_commit()


func reset_to_defaults() -> void:
	values = DEFAULTS.duplicate()
	var rec := recommend_preset()
	values["graphics_preset"] = rec
	for k in PRESET_KEYS:
		values[k] = PRESETS[rec][k]
	_commit()


func _commit() -> void:
	SaveSystem.data["settings"] = values.duplicate()
	_timer.start()
	apply()
	changed.emit()


func _flush() -> void:
	SaveSystem.save()


func apply() -> void:
	Engine.max_fps = int(values["max_fps"])
	var msaa := Viewport.MSAA_DISABLED
	if int(values["msaa"]) == 2:
		msaa = Viewport.MSAA_2X
	elif int(values["msaa"]) == 4:
		msaa = Viewport.MSAA_4X
	get_tree().root.msaa_3d = msaa
	for vp in get_tree().get_nodes_in_group("viewport3d"):
		vp.msaa_3d = msaa
	for light in get_tree().get_nodes_in_group("sun"):
		light.shadow_enabled = bool(values["shadows"])


func _make_fps_overlay() -> void:
	var layer := CanvasLayer.new()
	layer.layer = 100
	add_child(layer)
	_fps_label = Label.new()
	_fps_label.position = Vector2(14, 8)
	_fps_label.add_theme_font_size_override("font_size", 22)
	_fps_label.add_theme_color_override("font_color", Color(0.24, 0.86, 0.59))
	_fps_label.add_theme_color_override("font_outline_color", Color(0, 0, 0))
	_fps_label.add_theme_constant_override("outline_size", 6)
	_fps_label.visible = false
	layer.add_child(_fps_label)
