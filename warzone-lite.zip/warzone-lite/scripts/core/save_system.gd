extends Node
## Local save file: accounts, profiles, settings. Stored in user:// (private app storage on Android).
## Online accounts/server validation are future work; this is offline-only.

const SAVE_PATH := "user://warzone_save.json"
const BACKUP_PATH := "user://warzone_save.bak"
const SAVE_VERSION := 1
const INT_FIELDS := ["avatar", "level", "xp", "rank_index", "rank_points", "matches", "wins",
		"eliminations", "deaths", "gold", "suit_color", "accent_color"]

var data: Dictionary = {}


func _ready() -> void:
	load_data()


func _default_data() -> Dictionary:
	return {"version": SAVE_VERSION, "accounts": {}, "profiles": {}, "settings": {}, "remember": ""}


func default_profile(username: String, player_id: String) -> Dictionary:
	return {
		"username": username, "player_id": player_id, "avatar": 0,
		"level": 1, "xp": 0, "rank_index": 0, "rank_points": 0,
		"matches": 0, "wins": 0, "eliminations": 0, "deaths": 0,
		"fav_mode": "None yet", "gold": 0, "suit_color": 0, "accent_color": 0,
	}


func load_data() -> void:
	data = _default_data()
	if not FileAccess.file_exists(SAVE_PATH):
		return
	var f := FileAccess.open(SAVE_PATH, FileAccess.READ)
	if f == null:
		return
	var parsed: Variant = JSON.parse_string(f.get_as_text())
	f.close()
	if parsed is Dictionary:
		for k in data.keys():
			if parsed.has(k):
				data[k] = parsed[k]
		for key in data["profiles"].keys():
			data["profiles"][key] = _normalize_profile(data["profiles"][key])
	else:
		push_warning("Save file unreadable, starting fresh (backup kept).")
		DirAccess.copy_absolute(SAVE_PATH, BACKUP_PATH)


func _normalize_profile(p: Dictionary) -> Dictionary:
	var base := default_profile(str(p.get("username", "Player")), str(p.get("player_id", "000000000")))
	for k in base.keys():
		if p.has(k):
			base[k] = p[k]
	for k in INT_FIELDS:
		base[k] = int(base[k])
	return base


func save() -> void:
	var tmp := SAVE_PATH + ".tmp"
	var f := FileAccess.open(tmp, FileAccess.WRITE)
	if f == null:
		push_error("Could not write save file")
		return
	f.store_string(JSON.stringify(data))
	f.close()
	if FileAccess.file_exists(SAVE_PATH):
		DirAccess.copy_absolute(SAVE_PATH, BACKUP_PATH)
		DirAccess.remove_absolute(SAVE_PATH)
	DirAccess.rename_absolute(tmp, SAVE_PATH)


func _notification(what: int) -> void:
	if what == NOTIFICATION_APPLICATION_PAUSED or what == NOTIFICATION_WM_CLOSE_REQUEST:
		save()
