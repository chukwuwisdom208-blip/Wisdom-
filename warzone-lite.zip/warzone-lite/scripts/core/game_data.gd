extends Node
## Loads data-driven configuration (ranks, progression) from res://data.
## Edit the JSON files to rebalance without touching code.

var ranks_config: Dictionary = {}
var progression_config: Dictionary = {}


func _ready() -> void:
	ranks_config = _load_json("res://data/ranks.json")
	progression_config = _load_json("res://data/progression.json")


func _load_json(path: String) -> Dictionary:
	var f := FileAccess.open(path, FileAccess.READ)
	if f == null:
		push_error("Missing data file: " + path)
		return {}
	var parsed: Variant = JSON.parse_string(f.get_as_text())
	f.close()
	if parsed is Dictionary:
		return parsed
	push_error("Bad JSON in " + path)
	return {}
