extends Node
## Local (offline) accounts: sign in, create account, guest, remember me, recovery code.
## Passwords are salted + iterated SHA-256 hashes stored on the device only.
## NOTE: real online authentication needs a secure backend (future work).

const ALPHABET := "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
const GUEST_KEY := "guest"

var current_key: String = ""
var is_guest: bool = false


func get_profile() -> Dictionary:
	if current_key == "":
		return {}
	return SaveSystem.data["profiles"].get(current_key, {})


func _hash(secret: String, salt: String) -> String:
	var h := (salt + secret).sha256_text()
	for i in 1500:
		h = (h + salt).sha256_text()
	return h


func _salt() -> String:
	return str(randi()) + str(Time.get_ticks_usec())


func _make_code() -> String:
	var s := ""
	for i in 8:
		s += ALPHABET[randi() % ALPHABET.length()]
	return s


func _clean_code(code: String) -> String:
	return code.replace("-", "").replace(" ", "").to_upper()


func format_code(code: String) -> String:
	return code.substr(0, 4) + "-" + code.substr(4, 4)


func create_account(username: String, password: String, remember: bool) -> Dictionary:
	username = username.strip_edges()
	var rx := RegEx.new()
	rx.compile("^[A-Za-z0-9_]{3,16}$")
	if rx.search(username) == null:
		return {"ok": false, "error": "Username: 3-16 letters, numbers or _"}
	if password.length() < 6:
		return {"ok": false, "error": "Password must be at least 6 characters."}
	var key := username.to_lower()
	if key == GUEST_KEY or SaveSystem.data["accounts"].has(key):
		return {"ok": false, "error": "That username is taken."}
	var salt := _salt()
	var code := _make_code()
	SaveSystem.data["accounts"][key] = {
		"username": username, "salt": salt,
		"hash": _hash(password, salt), "recovery": _hash(code, salt),
	}
	var pid := str(randi_range(100000000, 999999999))
	SaveSystem.data["profiles"][key] = SaveSystem.default_profile(username, pid)
	_login(key, false, remember)
	return {"ok": true, "error": "", "code": format_code(code)}


func sign_in(username: String, password: String, remember: bool) -> Dictionary:
	var key := username.strip_edges().to_lower()
	var acc: Dictionary = SaveSystem.data["accounts"].get(key, {})
	if acc.is_empty() or _hash(password, acc["salt"]) != acc["hash"]:
		return {"ok": false, "error": "Invalid username or password."}
	_login(key, false, remember)
	return {"ok": true, "error": ""}


func recover(username: String, code: String, new_password: String) -> Dictionary:
	var key := username.strip_edges().to_lower()
	var acc: Dictionary = SaveSystem.data["accounts"].get(key, {})
	if acc.is_empty() or _hash(_clean_code(code), acc["salt"]) != acc["recovery"]:
		return {"ok": false, "error": "Username or recovery code is wrong."}
	if new_password.length() < 6:
		return {"ok": false, "error": "New password must be at least 6 characters."}
	acc["hash"] = _hash(new_password, acc["salt"])
	SaveSystem.save()
	return {"ok": true, "error": ""}


func guest_login() -> void:
	if not SaveSystem.data["profiles"].has(GUEST_KEY):
		var guest_name := "Guest" + str(randi_range(1000, 9999))
		SaveSystem.data["profiles"][GUEST_KEY] = SaveSystem.default_profile(guest_name, str(randi_range(100000000, 999999999)))
	_login(GUEST_KEY, true, false)


func try_auto_login() -> bool:
	var key: String = str(SaveSystem.data.get("remember", ""))
	if key == "":
		return false
	if key == GUEST_KEY or SaveSystem.data["accounts"].has(key):
		if SaveSystem.data["profiles"].has(key):
			current_key = key
			is_guest = (key == GUEST_KEY)
			return true
	return false


func sign_out() -> void:
	current_key = ""
	is_guest = false
	SaveSystem.data["remember"] = ""
	SaveSystem.save()


func _login(key: String, guest: bool, remember: bool) -> void:
	current_key = key
	is_guest = guest
	SaveSystem.data["remember"] = key if remember else ""
	SaveSystem.save()
